# PutFleetsFleetIdNewSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_free_move** | **bool** | Should free-move be enabled in the fleet | [optional] 
**motd** | **string** | New fleet MOTD in CCP flavoured HTML | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


