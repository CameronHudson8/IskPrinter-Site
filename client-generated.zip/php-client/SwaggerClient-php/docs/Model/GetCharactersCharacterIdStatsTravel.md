# GetCharactersCharacterIdStatsTravel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acceleration_gate_activations** | **int** | acceleration_gate_activations integer | [optional] 
**align_to** | **int** | align_to integer | [optional] 
**distance_warped_high_sec** | **int** | distance_warped_high_sec integer | [optional] 
**distance_warped_low_sec** | **int** | distance_warped_low_sec integer | [optional] 
**distance_warped_null_sec** | **int** | distance_warped_null_sec integer | [optional] 
**distance_warped_wormhole** | **int** | distance_warped_wormhole integer | [optional] 
**docks_high_sec** | **int** | docks_high_sec integer | [optional] 
**docks_low_sec** | **int** | docks_low_sec integer | [optional] 
**docks_null_sec** | **int** | docks_null_sec integer | [optional] 
**jumps_stargate_high_sec** | **int** | jumps_stargate_high_sec integer | [optional] 
**jumps_stargate_low_sec** | **int** | jumps_stargate_low_sec integer | [optional] 
**jumps_stargate_null_sec** | **int** | jumps_stargate_null_sec integer | [optional] 
**jumps_wormhole** | **int** | jumps_wormhole integer | [optional] 
**warps_high_sec** | **int** | warps_high_sec integer | [optional] 
**warps_low_sec** | **int** | warps_low_sec integer | [optional] 
**warps_null_sec** | **int** | warps_null_sec integer | [optional] 
**warps_to_bookmark** | **int** | warps_to_bookmark integer | [optional] 
**warps_to_celestial** | **int** | warps_to_celestial integer | [optional] 
**warps_to_fleet_member** | **int** | warps_to_fleet_member integer | [optional] 
**warps_to_scan_result** | **int** | warps_to_scan_result integer | [optional] 
**warps_wormhole** | **int** | warps_wormhole integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


