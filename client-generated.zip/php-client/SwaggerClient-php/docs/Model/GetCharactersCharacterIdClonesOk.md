# GetCharactersCharacterIdClonesOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**home_location** | [**\Swagger\Client\Model\GetCharactersCharacterIdClonesHomeLocation**](GetCharactersCharacterIdClonesHomeLocation.md) |  | [optional] 
**jump_clones** | [**\Swagger\Client\Model\GetCharactersCharacterIdClonesJumpClone[]**](GetCharactersCharacterIdClonesJumpClone.md) | jump_clones array | 
**last_clone_jump_date** | [**\DateTime**](\DateTime.md) | last_clone_jump_date string | [optional] 
**last_station_change_date** | [**\DateTime**](\DateTime.md) | last_station_change_date string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


