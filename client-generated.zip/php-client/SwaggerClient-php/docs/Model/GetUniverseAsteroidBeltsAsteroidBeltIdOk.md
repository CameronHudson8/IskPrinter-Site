# GetUniverseAsteroidBeltsAsteroidBeltIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | name string | 
**position** | [**\Swagger\Client\Model\GetUniverseAsteroidBeltsAsteroidBeltIdPosition**](GetUniverseAsteroidBeltsAsteroidBeltIdPosition.md) |  | 
**system_id** | **int** | The solar system this asteroid belt is in | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


