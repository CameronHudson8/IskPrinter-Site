# GetCorporationsCorporationIdRoles200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**character_id** | **int** | character_id integer | 
**grantable_roles** | **string[]** | grantable_roles array | [optional] 
**grantable_roles_at_base** | **string[]** | grantable_roles_at_base array | [optional] 
**grantable_roles_at_hq** | **string[]** | grantable_roles_at_hq array | [optional] 
**grantable_roles_at_other** | **string[]** | grantable_roles_at_other array | [optional] 
**roles** | **string[]** | roles array | [optional] 
**roles_at_base** | **string[]** | roles_at_base array | [optional] 
**roles_at_hq** | **string[]** | roles_at_hq array | [optional] 
**roles_at_other** | **string[]** | roles_at_other array | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


