# GetCharactersCharacterIdLocationOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**solar_system_id** | **int** | solar_system_id integer | 
**station_id** | **int** | station_id integer | [optional] 
**structure_id** | **int** | structure_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


