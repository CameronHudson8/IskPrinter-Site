# GetDogmaDynamicItemsTypeIdItemIdDogmaAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attribute_id** | **int** | attribute_id integer | 
**value** | **float** | value number | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


