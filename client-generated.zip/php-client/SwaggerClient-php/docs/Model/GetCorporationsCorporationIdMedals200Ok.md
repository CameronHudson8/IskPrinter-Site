# GetCorporationsCorporationIdMedals200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | [**\DateTime**](\DateTime.md) | created_at string | 
**creator_id** | **int** | ID of the character who created this medal | 
**description** | **string** | description string | 
**medal_id** | **int** | medal_id integer | 
**title** | **string** | title string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


