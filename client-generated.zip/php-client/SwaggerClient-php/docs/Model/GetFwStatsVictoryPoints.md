# GetFwStatsVictoryPoints

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_week** | **int** | Last week&#39;s victory points gained | 
**total** | **int** | Total victory points gained since faction warfare began | 
**yesterday** | **int** | Yesterday&#39;s victory points gained | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


