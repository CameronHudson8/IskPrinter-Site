# PostCharactersCharacterIdMailMail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**approved_cost** | **int** | approved_cost integer | [optional] [default to 0]
**body** | **string** | body string | 
**recipients** | [**\Swagger\Client\Model\PostCharactersCharacterIdMailRecipient[]**](PostCharactersCharacterIdMailRecipient.md) | recipients array | 
**subject** | **string** | subject string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


