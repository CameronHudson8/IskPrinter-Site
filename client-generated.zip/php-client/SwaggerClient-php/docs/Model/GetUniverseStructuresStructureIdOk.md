# GetUniverseStructuresStructureIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | The full name of the structure | 
**owner_id** | **int** | The ID of the corporation who owns this particular structure | 
**position** | [**\Swagger\Client\Model\GetUniverseStructuresStructureIdPosition**](GetUniverseStructuresStructureIdPosition.md) |  | [optional] 
**solar_system_id** | **int** | solar_system_id integer | 
**type_id** | **int** | type_id integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


