# GetCorporationsCorporationIdMedalsIssued200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**character_id** | **int** | ID of the character who was rewarded this medal | 
**issued_at** | [**\DateTime**](\DateTime.md) | issued_at string | 
**issuer_id** | **int** | ID of the character who issued the medal | 
**medal_id** | **int** | medal_id integer | 
**reason** | **string** | reason string | 
**status** | **string** | status string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


