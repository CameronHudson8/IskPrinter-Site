# PostCharactersAffiliation200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alliance_id** | **int** | The character&#39;s alliance ID, if their corporation is in an alliance | [optional] 
**character_id** | **int** | The character&#39;s ID | 
**corporation_id** | **int** | The character&#39;s corporation ID | 
**faction_id** | **int** | The character&#39;s faction ID, if their corporation is in a faction | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


