# GetCharactersCharacterIdStatsOrbital

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**strike_characters_killed** | **int** | strike_characters_killed integer | [optional] 
**strike_damage_to_players_armor_amount** | **int** | strike_damage_to_players_armor_amount integer | [optional] 
**strike_damage_to_players_shield_amount** | **int** | strike_damage_to_players_shield_amount integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


