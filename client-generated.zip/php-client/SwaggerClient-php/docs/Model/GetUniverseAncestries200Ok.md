# GetUniverseAncestries200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bloodline_id** | **int** | The bloodline associated with this ancestry | 
**description** | **string** | description string | 
**icon_id** | **int** | icon_id integer | [optional] 
**id** | **int** | id integer | 
**name** | **string** | name string | 
**short_description** | **string** | short_description string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


