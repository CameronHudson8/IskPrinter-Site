# GetUniverseBloodlines200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bloodline_id** | **int** | bloodline_id integer | 
**charisma** | **int** | charisma integer | 
**corporation_id** | **int** | corporation_id integer | 
**description** | **string** | description string | 
**intelligence** | **int** | intelligence integer | 
**memory** | **int** | memory integer | 
**name** | **string** | name string | 
**perception** | **int** | perception integer | 
**race_id** | **int** | race_id integer | 
**ship_type_id** | **int** | ship_type_id integer | 
**willpower** | **int** | willpower integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


