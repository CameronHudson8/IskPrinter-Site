# GetCharactersCharacterIdPlanets200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_update** | [**\DateTime**](\DateTime.md) | last_update string | 
**num_pins** | **int** | num_pins integer | 
**owner_id** | **int** | owner_id integer | 
**planet_id** | **int** | planet_id integer | 
**planet_type** | **string** | planet_type string | 
**solar_system_id** | **int** | solar_system_id integer | 
**upgrade_level** | **int** | upgrade_level integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


