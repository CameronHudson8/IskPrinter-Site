# GetUniverseConstellationsConstellationIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**constellation_id** | **int** | constellation_id integer | 
**name** | **string** | name string | 
**position** | [**\Swagger\Client\Model\GetUniverseConstellationsConstellationIdPosition**](GetUniverseConstellationsConstellationIdPosition.md) |  | 
**region_id** | **int** | The region this constellation is in | 
**systems** | **int[]** | systems array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


