# PostFleetsFleetIdWingsWingIdSquadsCreated

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**squad_id** | **int** | The squad_id of the newly created squad | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


