# GetCharactersCharacterIdStatsMarket

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accept_contracts_courier** | **int** | accept_contracts_courier integer | [optional] 
**accept_contracts_item_exchange** | **int** | accept_contracts_item_exchange integer | [optional] 
**buy_orders_placed** | **int** | buy_orders_placed integer | [optional] 
**cancel_market_order** | **int** | cancel_market_order integer | [optional] 
**create_contracts_auction** | **int** | create_contracts_auction integer | [optional] 
**create_contracts_courier** | **int** | create_contracts_courier integer | [optional] 
**create_contracts_item_exchange** | **int** | create_contracts_item_exchange integer | [optional] 
**deliver_courier_contract** | **int** | deliver_courier_contract integer | [optional] 
**isk_gained** | **int** | isk_gained integer | [optional] 
**isk_spent** | **int** | isk_spent integer | [optional] 
**modify_market_order** | **int** | modify_market_order integer | [optional] 
**search_contracts** | **int** | search_contracts integer | [optional] 
**sell_orders_placed** | **int** | sell_orders_placed integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


