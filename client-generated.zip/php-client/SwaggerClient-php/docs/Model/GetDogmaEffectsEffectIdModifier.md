# GetDogmaEffectsEffectIdModifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain** | **string** | domain string | [optional] 
**effect_id** | **int** | effect_id integer | [optional] 
**func** | **string** | func string | 
**modified_attribute_id** | **int** | modified_attribute_id integer | [optional] 
**modifying_attribute_id** | **int** | modifying_attribute_id integer | [optional] 
**operator** | **int** | operator integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


