# GetCorporationsCorporationIdMembertracking200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**base_id** | **int** | base_id integer | [optional] 
**character_id** | **int** | character_id integer | 
**location_id** | **int** | location_id integer | [optional] 
**logoff_date** | [**\DateTime**](\DateTime.md) | logoff_date string | [optional] 
**logon_date** | [**\DateTime**](\DateTime.md) | logon_date string | [optional] 
**ship_type_id** | **int** | ship_type_id integer | [optional] 
**start_date** | [**\DateTime**](\DateTime.md) | start_date string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


