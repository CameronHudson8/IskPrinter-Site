# GetUniverseMoonsMoonIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**moon_id** | **int** | moon_id integer | 
**name** | **string** | name string | 
**position** | [**\Swagger\Client\Model\GetUniverseMoonsMoonIdPosition**](GetUniverseMoonsMoonIdPosition.md) |  | 
**system_id** | **int** | The solar system this moon is in | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


