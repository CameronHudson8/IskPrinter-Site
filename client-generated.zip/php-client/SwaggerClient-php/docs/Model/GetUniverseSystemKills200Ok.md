# GetUniverseSystemKills200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**npc_kills** | **int** | Number of NPC ships killed in this system | 
**pod_kills** | **int** | Number of pods killed in this system | 
**ship_kills** | **int** | Number of player ships killed in this system | 
**system_id** | **int** | system_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


