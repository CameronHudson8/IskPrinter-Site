# GetUniverseSchematicsSchematicIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cycle_time** | **int** | Time in seconds to process a run | 
**schematic_name** | **string** | schematic_name string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


