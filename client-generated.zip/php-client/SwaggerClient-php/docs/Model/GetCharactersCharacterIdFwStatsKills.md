# GetCharactersCharacterIdFwStatsKills

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_week** | **int** | Last week&#39;s total number of kills by a given character against enemy factions | 
**total** | **int** | Total number of kills by a given character against enemy factions since the character enlisted | 
**yesterday** | **int** | Yesterday&#39;s total number of kills by a given character against enemy factions | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


