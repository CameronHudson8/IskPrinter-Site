# GetMarketsPrices200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**adjusted_price** | **double** | adjusted_price number | [optional] 
**average_price** | **double** | average_price number | [optional] 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


