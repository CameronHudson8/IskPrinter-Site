# GetCharactersCharacterIdMailLists200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mailing_list_id** | **int** | Mailing list ID | 
**name** | **string** | name string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


