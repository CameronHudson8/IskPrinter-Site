# GetUniversePlanetsPlanetIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | name string | 
**planet_id** | **int** | planet_id integer | 
**position** | [**\Swagger\Client\Model\GetUniversePlanetsPlanetIdPosition**](GetUniversePlanetsPlanetIdPosition.md) |  | 
**system_id** | **int** | The solar system this planet is in | 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


