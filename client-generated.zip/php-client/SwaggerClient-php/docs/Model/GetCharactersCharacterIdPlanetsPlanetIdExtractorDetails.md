# GetCharactersCharacterIdPlanetsPlanetIdExtractorDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cycle_time** | **int** | in seconds | [optional] 
**head_radius** | **float** | head_radius number | [optional] 
**heads** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdHead[]**](GetCharactersCharacterIdPlanetsPlanetIdHead.md) | heads array | 
**product_type_id** | **int** | product_type_id integer | [optional] 
**qty_per_cycle** | **int** | qty_per_cycle integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


