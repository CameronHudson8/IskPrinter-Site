# GetCorporationsCorporationIdWallets200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**balance** | **double** | balance number | 
**division** | **int** | division integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


