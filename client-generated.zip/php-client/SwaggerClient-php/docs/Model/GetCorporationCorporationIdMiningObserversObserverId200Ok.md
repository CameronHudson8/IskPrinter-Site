# GetCorporationCorporationIdMiningObserversObserverId200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**character_id** | **int** | The character that did the mining | 
**last_updated** | [**\DateTime**](\DateTime.md) | last_updated string | 
**quantity** | **int** | quantity integer | 
**recorded_corporation_id** | **int** | The corporation id of the character at the time data was recorded. | 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


