# GetUniverseRegionsRegionIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**constellations** | **int[]** | constellations array | 
**description** | **string** | description string | [optional] 
**name** | **string** | name string | 
**region_id** | **int** | region_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


