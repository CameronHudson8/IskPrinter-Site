# GetUniverseCategoriesCategoryIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category_id** | **int** | category_id integer | 
**groups** | **int[]** | groups array | 
**name** | **string** | name string | 
**published** | **bool** | published boolean | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


