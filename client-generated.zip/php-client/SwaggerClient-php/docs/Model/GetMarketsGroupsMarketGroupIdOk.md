# GetMarketsGroupsMarketGroupIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** | description string | 
**market_group_id** | **int** | market_group_id integer | 
**name** | **string** | name string | 
**parent_group_id** | **int** | parent_group_id integer | [optional] 
**types** | **int[]** | types array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


