# GetUniverseStarsStarIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**age** | **int** | Age of star in years | 
**luminosity** | **float** | luminosity number | 
**name** | **string** | name string | 
**radius** | **int** | radius integer | 
**solar_system_id** | **int** | solar_system_id integer | 
**spectral_class** | **string** | spectral_class string | 
**temperature** | **int** | temperature integer | 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


