# GetCharactersCharacterIdOpportunities200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**completed_at** | [**\DateTime**](\DateTime.md) | completed_at string | 
**task_id** | **int** | task_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


