# GetCharactersCharacterIdPlanetsPlanetIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdLink[]**](GetCharactersCharacterIdPlanetsPlanetIdLink.md) | links array | 
**pins** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdPin[]**](GetCharactersCharacterIdPlanetsPlanetIdPin.md) | pins array | 
**routes** | [**\Swagger\Client\Model\GetCharactersCharacterIdPlanetsPlanetIdRoute[]**](GetCharactersCharacterIdPlanetsPlanetIdRoute.md) | routes array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


