# GetCharactersCharacterIdPortraitOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**px128x128** | **string** | px128x128 string | [optional] 
**px256x256** | **string** | px256x256 string | [optional] 
**px512x512** | **string** | px512x512 string | [optional] 
**px64x64** | **string** | px64x64 string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


