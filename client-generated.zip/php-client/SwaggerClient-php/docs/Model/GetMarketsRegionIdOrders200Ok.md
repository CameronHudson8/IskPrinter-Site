# GetMarketsRegionIdOrders200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duration** | **int** | duration integer | 
**is_buy_order** | **bool** | is_buy_order boolean | 
**issued** | [**\DateTime**](\DateTime.md) | issued string | 
**location_id** | **int** | location_id integer | 
**min_volume** | **int** | min_volume integer | 
**order_id** | **int** | order_id integer | 
**price** | **double** | price number | 
**range** | **string** | range string | 
**system_id** | **int** | The solar system this order was placed | 
**type_id** | **int** | type_id integer | 
**volume_remain** | **int** | volume_remain integer | 
**volume_total** | **int** | volume_total integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


