# GetCharactersCharacterIdSkillqueue200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**finish_date** | [**\DateTime**](\DateTime.md) | Date on which training of the skill will complete. Omitted if the skill queue is paused. | [optional] 
**finished_level** | **int** | finished_level integer | 
**level_end_sp** | **int** | level_end_sp integer | [optional] 
**level_start_sp** | **int** | Amount of SP that was in the skill when it started training it&#39;s current level. Used to calculate % of current level complete. | [optional] 
**queue_position** | **int** | queue_position integer | 
**skill_id** | **int** | skill_id integer | 
**start_date** | [**\DateTime**](\DateTime.md) | start_date string | [optional] 
**training_start_sp** | **int** | training_start_sp integer | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


