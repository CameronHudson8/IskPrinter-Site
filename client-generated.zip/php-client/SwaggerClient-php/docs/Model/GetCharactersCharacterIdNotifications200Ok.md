# GetCharactersCharacterIdNotifications200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_read** | **bool** | is_read boolean | [optional] 
**notification_id** | **int** | notification_id integer | 
**sender_id** | **int** | sender_id integer | 
**sender_type** | **string** | sender_type string | 
**text** | **string** | text string | [optional] 
**timestamp** | [**\DateTime**](\DateTime.md) | timestamp string | 
**type** | **string** | type string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


