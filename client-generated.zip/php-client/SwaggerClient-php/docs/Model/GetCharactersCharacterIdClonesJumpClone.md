# GetCharactersCharacterIdClonesJumpClone

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**implants** | **int[]** | implants array | 
**jump_clone_id** | **int** | jump_clone_id integer | 
**location_id** | **int** | location_id integer | 
**location_type** | **string** | location_type string | 
**name** | **string** | name string | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


