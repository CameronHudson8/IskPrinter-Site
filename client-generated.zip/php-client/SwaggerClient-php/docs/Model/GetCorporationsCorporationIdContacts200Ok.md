# GetCorporationsCorporationIdContacts200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contact_id** | **int** | contact_id integer | 
**contact_type** | **string** | contact_type string | 
**is_watched** | **bool** | Whether this contact is being watched | [optional] 
**label_ids** | **int[]** | label_ids array | [optional] 
**standing** | **float** | Standing of the contact | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


