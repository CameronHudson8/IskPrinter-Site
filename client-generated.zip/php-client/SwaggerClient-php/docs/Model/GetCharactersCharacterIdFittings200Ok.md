# GetCharactersCharacterIdFittings200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** | description string | 
**fitting_id** | **int** | fitting_id integer | 
**items** | [**\Swagger\Client\Model\GetCharactersCharacterIdFittingsItem[]**](GetCharactersCharacterIdFittingsItem.md) | items array | 
**name** | **string** | name string | 
**ship_type_id** | **int** | ship_type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


