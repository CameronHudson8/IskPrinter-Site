# PostCharactersCharacterIdMailLabelsLabel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**color** | **string** | Hexadecimal string representing label color, in RGB format | [optional] [default to '#ffffff']
**name** | **string** | name string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


