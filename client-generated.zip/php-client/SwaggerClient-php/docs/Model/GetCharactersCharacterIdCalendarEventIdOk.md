# GetCharactersCharacterIdCalendarEventIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | [**\DateTime**](\DateTime.md) | date string | 
**duration** | **int** | Length in minutes | 
**event_id** | **int** | event_id integer | 
**importance** | **int** | importance integer | 
**owner_id** | **int** | owner_id integer | 
**owner_name** | **string** | owner_name string | 
**owner_type** | **string** | owner_type string | 
**response** | **string** | response string | 
**text** | **string** | text string | 
**title** | **string** | title string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


