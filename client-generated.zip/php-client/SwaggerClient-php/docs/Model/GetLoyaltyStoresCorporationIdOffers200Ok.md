# GetLoyaltyStoresCorporationIdOffers200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ak_cost** | **int** | Analysis kredit cost | [optional] 
**isk_cost** | **int** | isk_cost integer | 
**lp_cost** | **int** | lp_cost integer | 
**offer_id** | **int** | offer_id integer | 
**quantity** | **int** | quantity integer | 
**required_items** | [**\Swagger\Client\Model\GetLoyaltyStoresCorporationIdOffersRequiredItem[]**](GetLoyaltyStoresCorporationIdOffersRequiredItem.md) | required_items array | 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


