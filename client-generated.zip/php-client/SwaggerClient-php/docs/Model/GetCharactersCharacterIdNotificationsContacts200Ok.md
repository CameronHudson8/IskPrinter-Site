# GetCharactersCharacterIdNotificationsContacts200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **string** | message string | 
**notification_id** | **int** | notification_id integer | 
**send_date** | [**\DateTime**](\DateTime.md) | send_date string | 
**sender_character_id** | **int** | sender_character_id integer | 
**standing_level** | **float** | A number representing the standing level the receiver has been added at by the sender. The standing levels are as follows: -10 -&gt; Terrible | -5 -&gt; Bad |  0 -&gt; Neutral |  5 -&gt; Good |  10 -&gt; Excellent | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


