# GetSearchOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent** | **int[]** | agent array | [optional] 
**alliance** | **int[]** | alliance array | [optional] 
**character** | **int[]** | character array | [optional] 
**constellation** | **int[]** | constellation array | [optional] 
**corporation** | **int[]** | corporation array | [optional] 
**faction** | **int[]** | faction array | [optional] 
**inventory_type** | **int[]** | inventory_type array | [optional] 
**region** | **int[]** | region array | [optional] 
**solar_system** | **int[]** | solar_system array | [optional] 
**station** | **int[]** | station array | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


