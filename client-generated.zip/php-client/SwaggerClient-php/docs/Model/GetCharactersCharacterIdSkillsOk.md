# GetCharactersCharacterIdSkillsOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**skills** | [**\Swagger\Client\Model\GetCharactersCharacterIdSkillsSkill[]**](GetCharactersCharacterIdSkillsSkill.md) | skills array | 
**total_sp** | **int** | total_sp integer | 
**unallocated_sp** | **int** | Skill points available to be assigned | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


