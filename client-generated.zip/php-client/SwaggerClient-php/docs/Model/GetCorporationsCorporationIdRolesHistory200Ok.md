# GetCorporationsCorporationIdRolesHistory200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**changed_at** | [**\DateTime**](\DateTime.md) | changed_at string | 
**character_id** | **int** | The character whose roles are changed | 
**issuer_id** | **int** | ID of the character who issued this change | 
**new_roles** | **string[]** | new_roles array | 
**old_roles** | **string[]** | old_roles array | 
**role_type** | **string** | role_type string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


