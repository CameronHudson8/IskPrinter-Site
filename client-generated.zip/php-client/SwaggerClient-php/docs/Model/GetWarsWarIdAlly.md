# GetWarsWarIdAlly

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alliance_id** | **int** | Alliance ID if and only if this ally is an alliance | [optional] 
**corporation_id** | **int** | Corporation ID if and only if this ally is a corporation | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


