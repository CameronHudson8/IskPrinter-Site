# GetCharactersCharacterIdMail200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**from** | **int** | From whom the mail was sent | [optional] 
**is_read** | **bool** | is_read boolean | [optional] 
**labels** | **int[]** | labels array | [optional] 
**mail_id** | **int** | mail_id integer | [optional] 
**recipients** | [**\Swagger\Client\Model\GetCharactersCharacterIdMailRecipient[]**](GetCharactersCharacterIdMailRecipient.md) | Recipients of the mail | [optional] 
**subject** | **string** | Mail subject | [optional] 
**timestamp** | [**\DateTime**](\DateTime.md) | When the mail was sent | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


