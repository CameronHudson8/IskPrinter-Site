# GetUniverseStargatesStargateIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**destination** | [**\Swagger\Client\Model\GetUniverseStargatesStargateIdDestination**](GetUniverseStargatesStargateIdDestination.md) |  | 
**name** | **string** | name string | 
**position** | [**\Swagger\Client\Model\GetUniverseStargatesStargateIdPosition**](GetUniverseStargatesStargateIdPosition.md) |  | 
**stargate_id** | **int** | stargate_id integer | 
**system_id** | **int** | The solar system this stargate is in | 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


