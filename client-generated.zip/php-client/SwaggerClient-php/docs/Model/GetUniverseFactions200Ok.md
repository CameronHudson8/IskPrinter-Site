# GetUniverseFactions200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**corporation_id** | **int** | corporation_id integer | [optional] 
**description** | **string** | description string | 
**faction_id** | **int** | faction_id integer | 
**is_unique** | **bool** | is_unique boolean | 
**militia_corporation_id** | **int** | militia_corporation_id integer | [optional] 
**name** | **string** | name string | 
**size_factor** | **float** | size_factor number | 
**solar_system_id** | **int** | solar_system_id integer | [optional] 
**station_count** | **int** | station_count integer | 
**station_system_count** | **int** | station_system_count integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


