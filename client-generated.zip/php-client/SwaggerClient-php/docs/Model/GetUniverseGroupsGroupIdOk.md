# GetUniverseGroupsGroupIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category_id** | **int** | category_id integer | 
**group_id** | **int** | group_id integer | 
**name** | **string** | name string | 
**published** | **bool** | published boolean | 
**types** | **int[]** | types array | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


