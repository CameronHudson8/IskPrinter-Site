# GetUniverseSystemsSystemIdPlanet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**asteroid_belts** | **int[]** | asteroid_belts array | [optional] 
**moons** | **int[]** | moons array | [optional] 
**planet_id** | **int** | planet_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


