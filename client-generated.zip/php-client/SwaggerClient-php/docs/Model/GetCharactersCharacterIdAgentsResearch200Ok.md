# GetCharactersCharacterIdAgentsResearch200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agent_id** | **int** | agent_id integer | 
**points_per_day** | **float** | points_per_day number | 
**remainder_points** | **float** | remainder_points number | 
**skill_type_id** | **int** | skill_type_id integer | 
**started_at** | [**\DateTime**](\DateTime.md) | started_at string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


