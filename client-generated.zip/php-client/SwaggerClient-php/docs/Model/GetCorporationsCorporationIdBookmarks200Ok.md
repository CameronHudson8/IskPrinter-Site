# GetCorporationsCorporationIdBookmarks200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bookmark_id** | **int** | bookmark_id integer | 
**coordinates** | [**\Swagger\Client\Model\GetCorporationsCorporationIdBookmarksCoordinates**](GetCorporationsCorporationIdBookmarksCoordinates.md) |  | [optional] 
**created** | [**\DateTime**](\DateTime.md) | created string | 
**creator_id** | **int** | creator_id integer | 
**folder_id** | **int** | folder_id integer | [optional] 
**item** | [**\Swagger\Client\Model\GetCorporationsCorporationIdBookmarksItem**](GetCorporationsCorporationIdBookmarksItem.md) |  | [optional] 
**label** | **string** | label string | 
**location_id** | **int** | location_id integer | 
**notes** | **string** | notes string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


