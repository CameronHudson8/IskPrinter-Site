# GetFwWars200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**against_id** | **int** | The faction ID of the enemy faction. | 
**faction_id** | **int** | faction_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


