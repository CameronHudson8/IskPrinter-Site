# GetUniverseTypesTypeIdDogmaEffect

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**effect_id** | **int** | effect_id integer | 
**is_default** | **bool** | is_default boolean | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


