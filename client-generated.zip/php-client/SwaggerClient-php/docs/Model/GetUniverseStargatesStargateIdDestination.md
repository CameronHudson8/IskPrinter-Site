# GetUniverseStargatesStargateIdDestination

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stargate_id** | **int** | The stargate this stargate connects to | 
**system_id** | **int** | The solar system this stargate connects to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


