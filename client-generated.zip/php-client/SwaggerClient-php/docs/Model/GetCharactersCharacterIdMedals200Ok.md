# GetCharactersCharacterIdMedals200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**corporation_id** | **int** | corporation_id integer | 
**date** | [**\DateTime**](\DateTime.md) | date string | 
**description** | **string** | description string | 
**graphics** | [**\Swagger\Client\Model\GetCharactersCharacterIdMedalsGraphic[]**](GetCharactersCharacterIdMedalsGraphic.md) | graphics array | 
**issuer_id** | **int** | issuer_id integer | 
**medal_id** | **int** | medal_id integer | 
**reason** | **string** | reason string | 
**status** | **string** | status string | 
**title** | **string** | title string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


