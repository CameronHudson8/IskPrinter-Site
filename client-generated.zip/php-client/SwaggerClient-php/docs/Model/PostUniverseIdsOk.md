# PostUniverseIdsOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agents** | [**\Swagger\Client\Model\PostUniverseIdsAgent[]**](PostUniverseIdsAgent.md) | agents array | [optional] 
**alliances** | [**\Swagger\Client\Model\PostUniverseIdsAlliance[]**](PostUniverseIdsAlliance.md) | alliances array | [optional] 
**characters** | [**\Swagger\Client\Model\PostUniverseIdsCharacter[]**](PostUniverseIdsCharacter.md) | characters array | [optional] 
**constellations** | [**\Swagger\Client\Model\PostUniverseIdsConstellation[]**](PostUniverseIdsConstellation.md) | constellations array | [optional] 
**corporations** | [**\Swagger\Client\Model\PostUniverseIdsCorporation[]**](PostUniverseIdsCorporation.md) | corporations array | [optional] 
**factions** | [**\Swagger\Client\Model\PostUniverseIdsFaction[]**](PostUniverseIdsFaction.md) | factions array | [optional] 
**inventory_types** | [**\Swagger\Client\Model\PostUniverseIdsInventoryType[]**](PostUniverseIdsInventoryType.md) | inventory_types array | [optional] 
**regions** | [**\Swagger\Client\Model\PostUniverseIdsRegion[]**](PostUniverseIdsRegion.md) | regions array | [optional] 
**stations** | [**\Swagger\Client\Model\PostUniverseIdsStation[]**](PostUniverseIdsStation.md) | stations array | [optional] 
**systems** | [**\Swagger\Client\Model\PostUniverseIdsSystem[]**](PostUniverseIdsSystem.md) | systems array | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


