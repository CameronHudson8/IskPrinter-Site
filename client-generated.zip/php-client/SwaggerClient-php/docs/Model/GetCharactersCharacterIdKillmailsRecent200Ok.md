# GetCharactersCharacterIdKillmailsRecent200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**killmail_hash** | **string** | A hash of this killmail | 
**killmail_id** | **int** | ID of this killmail | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


