# GetCorporationsCorporationIdAssets200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_blueprint_copy** | **bool** | is_blueprint_copy boolean | [optional] 
**is_singleton** | **bool** | is_singleton boolean | 
**item_id** | **int** | item_id integer | 
**location_flag** | **string** | location_flag string | 
**location_id** | **int** | location_id integer | 
**location_type** | **string** | location_type string | 
**quantity** | **int** | quantity integer | 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


