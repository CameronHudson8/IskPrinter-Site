# PostCharactersCharacterIdFittingsItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flag** | **string** | Fitting location for the item. Entries placed in &#39;Invalid&#39; will be discarded. If this leaves the fitting with nothing, it will cause an error. | 
**quantity** | **int** | quantity integer | 
**type_id** | **int** | type_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


