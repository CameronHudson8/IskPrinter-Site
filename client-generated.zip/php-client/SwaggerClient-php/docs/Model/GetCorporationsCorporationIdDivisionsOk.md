# GetCorporationsCorporationIdDivisionsOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hangar** | [**\Swagger\Client\Model\GetCorporationsCorporationIdDivisionsHangarHangar[]**](GetCorporationsCorporationIdDivisionsHangarHangar.md) | hangar array | [optional] 
**wallet** | [**\Swagger\Client\Model\GetCorporationsCorporationIdDivisionsWalletWallet[]**](GetCorporationsCorporationIdDivisionsWalletWallet.md) | wallet array | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


