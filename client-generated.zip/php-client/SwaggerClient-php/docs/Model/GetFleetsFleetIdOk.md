# GetFleetsFleetIdOk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_free_move** | **bool** | Is free-move enabled | 
**is_registered** | **bool** | Does the fleet have an active fleet advertisement | 
**is_voice_enabled** | **bool** | Is EVE Voice enabled | 
**motd** | **string** | Fleet MOTD in CCP flavoured HTML | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


