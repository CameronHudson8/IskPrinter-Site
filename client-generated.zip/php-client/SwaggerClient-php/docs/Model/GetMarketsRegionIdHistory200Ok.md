# GetMarketsRegionIdHistory200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**average** | **double** | average number | 
**date** | [**\DateTime**](\DateTime.md) | The date of this historical statistic entry | 
**highest** | **double** | highest number | 
**lowest** | **double** | lowest number | 
**order_count** | **int** | Total number of orders happened that day | 
**volume** | **int** | Total | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


