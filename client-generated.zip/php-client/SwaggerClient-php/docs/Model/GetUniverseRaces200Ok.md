# GetUniverseRaces200Ok

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alliance_id** | **int** | The alliance generally associated with this race | 
**description** | **string** | description string | 
**name** | **string** | name string | 
**race_id** | **int** | race_id integer | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


