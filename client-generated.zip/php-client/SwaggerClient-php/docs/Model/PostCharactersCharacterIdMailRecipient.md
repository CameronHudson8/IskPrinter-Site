# PostCharactersCharacterIdMailRecipient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipient_id** | **int** | recipient_id integer | 
**recipient_type** | **string** | recipient_type string | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


